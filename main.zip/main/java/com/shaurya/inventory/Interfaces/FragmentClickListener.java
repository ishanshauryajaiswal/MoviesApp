package com.shaurya.inventory.Interfaces;

import android.view.View;

import com.shaurya.inventory.Model.Variant;

/**
 * Created by shaurya on 07/04/18.
 */

public interface FragmentClickListener {
    void onCompanySelected(int companyID);
    void onProductSelected(View v, int productID);
    void onVariantSelected(Variant variant);
    void onStockModeSelected(int stockMode);
    void onStockInModeSelected(int stockInModeId);
    void onStockOutModeSelected(int stockOutModeId);
    void onSubmitted(String name, int quantity, String batch, String lot, String date);
}
