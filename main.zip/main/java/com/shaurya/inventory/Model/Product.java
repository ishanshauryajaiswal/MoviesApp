package com.shaurya.inventory.Model;

/**
 * Created by shaurya on 07/04/18.
 */

public class Product {
    private int companyId;
    private int productId;
    private String productName;

    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
