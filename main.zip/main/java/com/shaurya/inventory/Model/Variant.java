package com.shaurya.inventory.Model;

import java.io.Serializable;

/**
 * Created by shaurya on 08/04/18.
 */

public class Variant implements Serializable{
    private int productID;
    private int quantity;
    private String unit;

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
    public String toString(){
        return this.getQuantity()+" "+this.getUnit();
    }
}
