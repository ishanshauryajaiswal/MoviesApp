package com.shaurya.inventory;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.shaurya.inventory.Interfaces.FragmentClickListener;
import com.shaurya.inventory.Model.Product;

import java.util.List;

/**
 * Created by shaurya on 07/04/18.
 */

public class ProductListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private List<Product> mList;
    private FragmentClickListener mListener;
    public ProductListAdapter(Context mContext, List<Product> mList, FragmentClickListener mListener) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListener = mListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.cell_product_recycler_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final Product product = mList.get(position);
        ViewHolder viewHolder = (ViewHolder)holder;
        viewHolder.tvProductName.setText(product.getProductName());
        viewHolder.tvProductName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onProductSelected(view, product.getProductId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvProductName;
        public ViewHolder(View v){
            super(v);
            tvProductName = (TextView) v.findViewById(R.id.tvProductName);
        }
    }
}
