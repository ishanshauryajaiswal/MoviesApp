package com.shaurya.inventory.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.shaurya.inventory.Interfaces.FragmentClickListener;
import com.shaurya.inventory.Model.MainObject;
import com.shaurya.inventory.Model.Variant;
import com.shaurya.inventory.R;

/**
 * Created by shaurya on 07/04/18.
 */

public class HomeActivity extends AppCompatActivity implements FragmentClickListener{

    FragmentManager fragmentManager;
    private MainObject mainObject;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mainObject = new MainObject();
        CompanyFragment companyFragment = CompanyFragment.getInstance();
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,companyFragment,"tag_fragment_company")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onCompanySelected(int companyId) {
        mainObject.setCompanyID(companyId);
        ProductFragment productFragment = ProductFragment.getInstance(this,companyId);
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,productFragment,"tag_fragment_product")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onProductSelected(View v, int productID) {
        mainObject.setProductID(productID);
        ProductFragment productFragment = (ProductFragment)fragmentManager.findFragmentByTag("tag_fragment_product");
        productFragment.showPopup(v, productID);
    }

    @Override
    public void onVariantSelected(Variant variant) {
        mainObject.setVariant(variant);
        StockInOutFragment stockInOutFragment = StockInOutFragment.getInstance();
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,stockInOutFragment,"tag_fragment_stockInOut")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onStockModeSelected(int stockMode) {
        mainObject.setStockMode(stockMode);
        if (stockMode == 1){
            StockInDetailFragment stockInDetailFragment = StockInDetailFragment.getInstance();
            fragmentManager.beginTransaction().replace(R.id.fragmentContainer,stockInDetailFragment,"tag_fragment_stockInDetail")
                    .addToBackStack(null)
                    .commit();
        }
        else if (stockMode == 2){
            StockOutDetailFragment stockOutDetailFragment = StockOutDetailFragment.getInstance();
            fragmentManager.beginTransaction().replace(R.id.fragmentContainer,stockOutDetailFragment,"tag_fragment_stockOutDetail")
                    .addToBackStack(null)
                    .commit();
        }
        else {

        }
    }

    @Override
    public void onStockInModeSelected(int modeId) {
        mainObject.setStockDetailMode(modeId);
        MainFragment mainFragment = MainFragment.getInstance(this, mainObject.getCompanyID());
        fragmentManager.beginTransaction().replace(R.id.fragmentContainer,mainFragment,"tag_fragment_main")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onStockOutModeSelected(int modeId) {
        mainObject.setStockDetailMode(modeId);
    }

    @Override
    public void onSubmitted(String name, int quantity, String batch, String lot, String date) {
        mainObject.setDistributorName(name);
        mainObject.setQuantity(quantity);
        mainObject.setBatchNo(batch);
        mainObject.setLotNo(lot);
        mainObject.setDate(date);
    }
}
