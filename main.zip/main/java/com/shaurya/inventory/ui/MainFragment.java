package com.shaurya.inventory.ui;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.shaurya.inventory.Interfaces.FragmentClickListener;
import com.shaurya.inventory.R;
import com.shaurya.inventory.util.Maps;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by shaurya on 07/04/18.
 */

public class MainFragment extends Fragment {
    private FragmentClickListener mListener;
    private EditText etName, etQuantity, etBatchNo, etLotNo;
    private TextView tvCompanyName, tvDate;
    private Button btnSubmit;
    private int companyID;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        companyID = getArguments().getInt(getString(R.string.key_company_id));
        initView(view);
    }

    private void initView(View view) {
        final Calendar cal = Calendar.getInstance();
        final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String currTime = sdf.format(cal.getTime());
        etName = (EditText) view.findViewById(R.id.etName);
        etQuantity = (EditText)view.findViewById(R.id.etQuantity);
        etBatchNo = (EditText)view.findViewById(R.id.etBatchNo);
        etLotNo = (EditText)view.findViewById(R.id.etLotNo);
        tvCompanyName = (TextView)view.findViewById(R.id.tvCompanyName);
        tvDate = (TextView)view.findViewById(R.id.tvDate);
        btnSubmit = (Button)view.findViewById(R.id.btn_submit);
        String s = Maps.companyMap.get(companyID);
        tvCompanyName.setText(Maps.companyMap.get(companyID));
        tvDate.setText(currTime);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitButtonClicked(etName.getText().toString().trim(),
                        Integer.parseInt(etQuantity.getText().toString()),
                        etBatchNo.getText().toString(),
                        etLotNo.getText().toString(),
                        sdf.format(cal.getTime()));
            }
        });
    }

    public static MainFragment getInstance(Context context, int companyID){
        MainFragment mainFragment = new MainFragment();
        Bundle args = new Bundle();
        args.putInt(context.getString(R.string.key_company_id),companyID);
        mainFragment.setArguments(args);
        return mainFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException(getActivity().toString() + " must implement FragmentClickListener");
    }

    public void submitButtonClicked(String name, int quantity, String batchNo, String lotNo, String date){
        mListener.onSubmitted(name, quantity, batchNo, lotNo, date);
    }
}

