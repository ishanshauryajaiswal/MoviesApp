package com.shaurya.inventory.ui;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.shaurya.inventory.Interfaces.FragmentClickListener;
import com.shaurya.inventory.Model.Product;
import com.shaurya.inventory.Model.Variant;
import com.shaurya.inventory.ProductListAdapter;
import com.shaurya.inventory.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shaurya on 07/04/18.
 */

public class ProductFragment extends android.support.v4.app.Fragment {

    RecyclerView rvProducts;
    ProductListAdapter mAdapter;
    List<Product> mProductList = new ArrayList<>();
    List<Variant> mVariantList = new ArrayList<>();
    private FragmentClickListener mListener;
    int companyID, productID, variantQuantity;
    ProgressBar progressBar;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_product,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvProducts = (RecyclerView)view.findViewById(R.id.rvProducts);
        mAdapter = new ProductListAdapter(getContext(),mProductList,mListener);
        rvProducts.setLayoutManager(new LinearLayoutManager(getContext()));
        rvProducts.setAdapter(mAdapter);
        companyID = getArguments().getInt(getString(R.string.key_company_id));
        progressBar = (ProgressBar) getActivity().findViewById(R.id.progressBar_home);
        if (mProductList.size()==0) {
            progressBar.setVisibility(View.VISIBLE);
            ParseQuery<ParseObject> query = ParseQuery.getQuery("Products");
            query.whereEqualTo("CompanyID", companyID);
            query.findInBackground(new FindCallback<ParseObject>() {
                public void done(List<ParseObject> productList, ParseException e) {
                    progressBar.setVisibility(View.GONE);
                    if (e == null) {
                        Log.d("products", "Retrieved " + productList.size() + " products");
                        for (ParseObject p : productList) {
                            Product product = new Product();
                            product.setCompanyId(p.getInt("CompanyID"));
                            product.setProductId(p.getInt("ProductID"));
                            product.setProductName(p.getString("ProductName"));
                            mProductList.add(product);
                        }
                        mAdapter.notifyDataSetChanged();
                    } else {
                        Log.d("products", "Error: " + e.getMessage());
                    }
                }
            });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException(getActivity().toString() + " must implement FragmentClickListener");
    }

    public static ProductFragment getInstance(Context c,int companyID){
        ProductFragment productFragment = new ProductFragment();
        Bundle args = new Bundle();
        args.putInt(c.getString(R.string.key_company_id),companyID);
        productFragment.setArguments(args);
        return productFragment;
    }

    public void showPopup(View anchorView, int productID) {
        this.productID = productID;
        final List<String> listForListView = new ArrayList<>();
        final ArrayAdapter<String> mArrayAdapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,listForListView);
        progressBar.setVisibility(View.VISIBLE);
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Variants");
        query.whereEqualTo("productID", productID);
        query.findInBackground(new FindCallback<ParseObject>() {
            public void done(List<ParseObject> variantList, ParseException e) {
                progressBar.setVisibility(View.GONE);
                if (e == null) {
                    Log.d("variants", "Retrieved " + variantList.size() + " variants");
                    for (ParseObject p:variantList){
                        Variant variant = new Variant();
                        variant.setQuantity(p.getInt("quantity"));
                        variant.setProductID(p.getInt("productID"));
                        variant.setUnit(p.getString("unit"));
                        mVariantList.add(variant);
                        listForListView.add(variant.toString());
                    }
                    mArrayAdapter.notifyDataSetChanged();
                } else {
                    Log.d("products", "Error: " + e.getMessage());
                }
            }
        });

        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View popupView = layoutInflater.inflate(R.layout.popup_layout_product, null);
        ListView lvVariant = popupView.findViewById(R.id.lvProductVariant);
        final PopupWindow popupWindow = new PopupWindow(popupView, 500, 500);
        lvVariant.setAdapter(mArrayAdapter);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable());
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0,0);
        lvVariant.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                popupWindow.dismiss();
                mListener.onVariantSelected(mVariantList.get(position));
            }
        });
    }

}
