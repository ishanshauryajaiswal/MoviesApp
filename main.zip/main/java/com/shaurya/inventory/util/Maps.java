package com.shaurya.inventory.util;

import java.util.HashMap;

/**
 * Created by shaurya on 09/04/18.
 */

public class Maps {

    public static HashMap<Integer,String> companyMap = new HashMap<Integer, String>()
    {{
        put(1,"Samrath Pharmaceuticals");
        put(2,"Samrath Udyog Samiti");
        put(3,"Marketing Material");
        put(4,"Packaging Material");
    }};
}
